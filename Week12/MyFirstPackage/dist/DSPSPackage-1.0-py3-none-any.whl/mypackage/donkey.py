from playsound import playsound

def play():
    """Play sound
    Parameters:
        None
    Return:
        None
    """
    playsound("donkey.mp3")